BOOTSTRAP JAVLO INTEGRATION
===========================

config.properties
-----------------

banner = true/false   : active of not a banner, the banner file by default is "img/default_banner.jpg", the renderer is "banner.jsp"

change table to .table in normalize.less for wysywig